package cs6235.a1;

public class Options {
	public static String queriesPath;
}
