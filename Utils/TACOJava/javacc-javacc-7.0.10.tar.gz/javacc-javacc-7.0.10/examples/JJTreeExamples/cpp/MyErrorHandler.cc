/*
 * MyErrorHandler.cpp
 *
 *  Created on: 12 avr. 2014
 *      Author: FrancisANDRE
 */

#include "MyErrorHandler.h"

namespace @NAMESPACE@ {

MyErrorHandler::MyErrorHandler() {
}

MyErrorHandler::~MyErrorHandler() {
}

} /* namespace @NAMESPACE@ */
